<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.searchbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <img src="<?php echo e(asset("img/Hotel1.jpg")); ?>" alt="" style="height: 180px; width:320px">
        </div>
        <div class="col-md-6">
            <h1 class="text-warning">
                product name
            </h1>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. At porro quis laborum pariatur nesciunt modi perspiciatis quos aperiam totam!
                Minus voluptate at iusto aliquid soluta ipsam temporibus eaque deserunt. Vel.
            </p>
            <button class="btn btn-success">Buy now</button>
        </div>
    </div>
    
    <!--category section-->
    <div class="category-section pt-5">
        <h3 class="text-primary py-3">Popular Category</h1>
        <div class="cate-cou">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="category-list">
                <img src="<?php echo e(asset('storage/' . $category->category_img)); ?>" alt="" class="cate-img">
                <h6 class="text-success text-center pt-3"><?php echo e($category->name); ?></h6>
                <a href="" class="btn btn-light text-center">Explore Now</a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="py-5">
            <a href="<?php echo e(route('allcategory.index')); ?>" class="btn btn-dark">See all Categories</a>
        </div>
    </div>

    <!--products trandinging-->
    <div class="tranding-products my-5">
        <H3 class="text-warning">Tranding products</H3>
       <div class="row mt-5">
           <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="col-md-6 mb-4 pro-flex">
            <div class="ap text-center py-3 px-2">
                <img src="<?php echo e(asset('img/Hotel1.jpg')); ?>" alt="" class="product-size">
                <h3><?php echo e($product->amazon_product_name); ?></h3>
                <p><?php echo e(Str::limit($product->amazon_details, 60, '....')); ?></p>
                <h5 class="text-primary">Price: <?php echo e($product->amazon_prize); ?> INR</h5>
                <a href="<?php echo e($product->amazon_link); ?>" target="blank" class="btn btn-primary">Buy Now</a>
                <a href="<?php echo e(route('product.show', $product->slug)); ?>" class="btn btn-success">Compare Product</a>
            </div>
            <div class="fp text-center py-3 px-2">
              <img src="<?php echo e(asset('img/Hotel1.jpg')); ?>" alt="" class="product-size">
              <h3><?php echo e($product->flipk_product_name); ?></h3>
              <p><?php echo e(Str::limit($product->flipkart_details, 60, '....')); ?></p>
              <h5 class="text-primary">Price: <?php echo e($product->flipkart_prize); ?> INR</h5>
              <a href="<?php echo e($product->flipkart_link); ?>" class="btn btn-primary">Buy Now</a>
              <a href="<?php echo e(route('product.show', $product->slug)); ?>" class="btn btn-success">Compare Product</a>
            </div>
         </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamppp\htdocs\jui\blog\resources\views/welcome.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
<div class="row">
  <h1 class="text-primary py-5">Category Create</h1>
  <div class="col-md-12">
      <form action="<?php echo e(route('category.store')); ?>" method="post" enctype="multipart/form-data">
          <?php echo $__env->make('todos.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <button class="btn btn-primary" type="submit">Add category</button>
      </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamppp\htdocs\jui\blog\resources\views/todos/todocreate.blade.php ENDPATH**/ ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="category-section pt-2">
    <h3 class="text-primary py-3">Popular Category</h1>
    <div class="cate-cou">
        <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="category-list">
            <img src="<?php echo e(asset('storage/' . $category->category_img)); ?>" alt="" class="cate-img">
            <h6 class="text-success text-center pt-3"><?php echo e($category->name); ?></h6>
            <a href="" class="btn btn-light text-center">Explore Now</a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamppp\htdocs\jui\blog\resources\views/categories.blade.php ENDPATH**/ ?>
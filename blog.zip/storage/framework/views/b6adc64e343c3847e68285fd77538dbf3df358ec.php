
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <table class="table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col"> Amazon Product name</th>
                <th scope="col">Amazon Product Price</th>
                <th scope="col">Flipkart Product  Name</th>
                <th scope="col">Flipkart Product Price</th>
                <th scope="col"><a href="<?php echo e(route('myproduct.create')); ?>" class="btn btn-success">Add Product</a></th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($product->id); ?></th>
                <td><?php echo e($product->amazon_product_name); ?></td>
                <td><?php echo e($product->amazon_prize); ?> INR</td>
                <td><?php echo e($product->flipk_product_name); ?></td>
                <td><?php echo e($product->flipkart_prize); ?> INR</td>
                <td><a href="<?php echo e(route('product.edit', ['product'=>$product])); ?>" class="btn btn-warning">Edit</a></td>
                <td><a href="<?php echo e(route('myproduct.show', $product->id)); ?>" class="btn btn-primary">Details</a></td>
                <td>
                  <form action="<?php echo e(route('product.destroy', $product->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger" type="submit">Delete</button>
                  </form>
                  
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </tbody>
          </table>
    </div>
</div>
<div class="row">
  <div class="col-md-12 d-flex justify-content-center pt-4">
    <?php echo e($products->links()); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamppp\htdocs\jui\blog\resources\views/todos/productList.blade.php ENDPATH**/ ?>
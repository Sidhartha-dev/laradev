
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.searchbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="tranding-products my-5">
    <H3 class="text-warning">Featured products</H3>
   <div class="row mt-5">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-6 mb-4 pro-flex">
     <div class="ap text-center py-3 px-2">
         <img src="<?php echo e(asset('storage/' . $product->amazon_image)); ?>" alt="" class="product-size">
         <h3><?php echo e($product->amazon_product_name); ?></h3>
         <?php echo e(Str::limit($product->amazon_details, 60, '....')); ?>

         <h5 class="text-primary">Price: <?php echo e($product->amazon_prize); ?> INR</h5>
         <a href="<?php echo e($product->amazon_link); ?>" target="blank" class="btn btn-primary">Buy Now</a>
         <a href="<?php echo e(route('product.show', $product->slug)); ?>" class="btn btn-success">Compare Product</a>
     </div>
     <div class="fp text-center py-3 px-2">
       <img src="<?php echo e(asset('storage/' . $product->flipkart_image)); ?>" alt="" class="product-size">
       <h3><?php echo e($product->flipk_product_name); ?></h3>
       <p><?php echo e(Str::limit($product->flipkart_details, 60, '....')); ?></p>
       <h5 class="text-primary">Price: <?php echo e($product->flipkart_prize); ?> INR</h5>
       <a href="<?php echo e($product->flipkart_link); ?>" target="blank" class="btn btn-primary">Buy Now</a>
       <a href="<?php echo e(route('product.show', $product->slug)); ?>" class="btn btn-success">Compare Product</a>
     </div>
  </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </div>

   <div class="row">
     <div class="col-md-12 d-flex justify-content-center pt-4">
       <?php echo e($products->links()); ?>

     </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamppp\htdocs\jui\blog\resources\views/products.blade.php ENDPATH**/ ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<h1 class="py-4 text-center">category</h1>
<div class="row justify-content-center">
    <div class="col-md-8">
        <table class="table table-bordered table-white">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Category name</th>
                <th scope="col">Category Image</th>
                <th scope="col">
                    <a href="<?php echo e(route('category.create')); ?>" class="btn btn-success">Add Category</a>
                </th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <th scope="row"><?php echo e($category->id); ?></th>
                <td><?php echo e($category->name); ?></td>
                <td><img src="<?php echo e(asset('storage/' . $category->category_img)); ?>" alt="" class="category-list-img"></td>
                <td>
                    <form action="<?php echo e(route('category.destroy', $category->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger" type="submit">Delete</button>
                      </form>
                </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          
    </div>
</div>
<div class="row">
    <div class="col-md-12 d-flex justify-content-center pt-4">
      <?php echo e($categories->links()); ?>

    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamppp\htdocs\jui\blog\resources\views/todos/categorylist.blade.php ENDPATH**/ ?>
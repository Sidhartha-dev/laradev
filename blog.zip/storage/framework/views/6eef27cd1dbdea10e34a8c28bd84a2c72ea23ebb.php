

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <h3 class="text-warning text-center my-5">Producty details</h3>
      <form action="<?php echo e(route('myproduct.store')); ?>" method="post" enctype="multipart/form-data">
          <?php echo $__env->make('todos.productform', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <button class="btn btn-primary" type="submit">Add Product</button>
      </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamppp\htdocs\jui\blog\resources\views/todos/productcreate.blade.php ENDPATH**/ ?>
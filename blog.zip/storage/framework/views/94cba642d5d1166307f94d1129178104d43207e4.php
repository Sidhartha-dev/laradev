<div class="form-group">
    <label for="name">Category name</label>
    <input type="text" name="name" class="form-control" placeholder="Name...">
    <div><?php echo e($errors->first('name')); ?></div>
</div>
<div class="form-group">
    <label for="image">Category image</label>
    <input type="file" name="category_img">
    <div><?php echo e($errors->first('name')); ?></div>
</div>
<?php echo csrf_field(); ?>
<?php /**PATH E:\xamppp\htdocs\jui\blog\resources\views/todos/form.blade.php ENDPATH**/ ?>
<div class="container">
<div class="row">
    <div class="col-md-6 pt-2">
         <input type="checkbox" class="checkbox" id="checkbox">
         <label for="checkbox" class="label">
             <i class="fa fa-sun-o" aria-hidden="true"></i>
             <i class="fa fa-moon-o" aria-hidden="true"></i>
             <div class="ball"></div>
         </label>
    </div>
    <div class="col-md-6">
       <div class="searchbox float-right pt-2">
        <div class="input-display">
           <input type="text" class="inhi" placeholder="search product...">
           <button class="btnt"><i class="fa fa-search" aria-hidden="true"></i></button>
        </div>
       </div>
    </div>
</div>
</div>